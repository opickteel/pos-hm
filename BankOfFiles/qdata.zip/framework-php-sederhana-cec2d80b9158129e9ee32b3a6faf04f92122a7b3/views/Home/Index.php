<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>Nama Pengguna</th>
            <th>Email</th>
        </tr>
    </thead>

    <tbody>
        <tr>
            <td colspan="2">Kosong</td>
        </tr>
    </tbody>
</table>
